package iss.java.mail;

import java.io.IOException;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.LoggingMXBean;

/**
 * �ʼ�������
 **/
public class Operation {
    private static LoggingMXBean log = LogManager.getLoggingMXBean();
   
    private static final String CONFIGPATH = "mail.properties";
    private static final String SMTP = "smtp";
    private static final String EMAILREGEX = "emailRegex";

	private static final String StringUtils = null;
    private static Properties mailConfig;
   
    static {
        reloadPro();
    }
    /**
     * ��ȡ�����ӦSMTP������
     * @param mail
     *
     */
    public static String getMail2SMTP(String mail) {
        return (String)getConfigValue(SMTP);
    }
    public static String getConfigValue(String key) {
        if(null == mailConfig)
            reloadPro();
        return (String)mailConfig.get(key);
    }
    /**
     * ���¼��������ļ�
     */
    public static void reloadPro(){
        mailConfig = new Properties();
        try {
            mailConfig.load(Operation.class.getClassLoader().getResourceAsStream(CONFIGPATH));
        } catch (IOException e) {
            log.hashCode();
        }
    }
    /**
     * �����ַ�Ƿ���ȷ
     * @param email
     *
     */
    public static boolean isEmail(String email) {
        if(!StringUtils.isEmpty())
            return email.matches(getConfigValue(EMAILREGEX));
        return false;
    }
}

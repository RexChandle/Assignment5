package iss.java.mail;

import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.LoggingMXBean;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.URLName;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MailControl {
    private LoggingMXBean log = LogManager.getLoggingMXBean();
    /**
     * ����
     */
    private String subject;   
    /**
     * ���������ַ
     */
    private String sendMail;
    /**
     * ������������
     */
    private String sendMailPassword;
    /**
     * �ռ���
     */
    private List<String> tos;
    /**
     * ����
     */
    private List<String> ccs;
    /**
     * ��������
     */
    private String content;
    /**
     * ���ݱ���
     */
    private String character;
    /**
     * ���ͷ�������ַ
     */
    private String mailHost;
    /**
     *  ����
     */
    private List<String> accessories;
    /**
     * �����Ƿ���ҪУ��
     */
    private String isCheckSend;
    /**
     *
     * @param subject ����
     * @param sendMail ������
     * @param sendMailPassword ����
     * @param recipient �ռ���
     * @param content ����
     * @param character  �����ַ���
     * @param mailHost SMTP����
     * @param isCheckSend �Ƿ���Ҫ��֤
     */
    public MailControl(String subject, String sendMail, String sendMailPassword,
            List<String> recipient, String content, String character,
            String mailHost, String isCheckSend) {
        this.subject = subject;
        this.sendMail = sendMail;
        this.sendMailPassword = sendMailPassword;
        this.tos = recipient;
        this.content = content;
        this.character = character;
        this.mailHost = mailHost;
        this.isCheckSend = isCheckSend;
    }
    /**
     *
     * @param subject ����
     * @param sendMail ������
     * @param sendMailPassword ����
     * @param tos �ռ���
     * @param content ����
     * @param character  �����ַ���
     * @param mailHost SMTP����
     * @param isCheckSend �Ƿ���Ҫ��֤
     * @param accessories ����
     */
    public MailControl(String subject, String sendMail, String sendMailPassword,
            List<String> tos, String content, String character,
            String mailHost, List<String> accessories, String isCheckSend) {
        this.subject = subject;
        this.sendMail = sendMail;
        this.sendMailPassword = sendMailPassword;
        this.tos = tos;
        this.content = content;
        this.character = character;
        this.mailHost = mailHost;
        this.accessories = accessories;
        this.isCheckSend = isCheckSend;
    }
    /**
     *
     * @param subject ����
     * @param sendMail ������
     * @param sendMailPassword ����
     * @param content ����
     * @param character  �����ַ���
     * @param mailHost SMTP����
     * @param isCheckSend �Ƿ���Ҫ��֤
     * @param accessories ����
     * @param cc
     */
    public MailControl(String subject, String sendMail, String sendMailPassword,
            List<String> takeMail, String content, String character,
            String mailHost, List<String> accessories, String isCheckSend, List<String> cc) {
        this.subject = subject;
        this.sendMail = sendMail;
        this.sendMailPassword = sendMailPassword;
        this.tos = takeMail;
        this.content = content;
        this.character = character;
        this.mailHost = mailHost;
        this.accessories = accessories;
        this.isCheckSend = isCheckSend;
        this.ccs = cc;
    }
    public String getSubject() {
        return subject;
    }
    public void setSubject(String subject) {
        this.subject = subject;
    }
    public String getSendMail() {
        return sendMail;
    }
    public void setSendMail(String sendMail) {
        this.sendMail = sendMail;
    }
    public String getSendMailPassword() {
        return sendMailPassword;
    }
    public void setSendMailPassword(String sendMailPassword) {
        this.sendMailPassword = sendMailPassword;
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getCharacter() {
        return character;
    }
    public void setCharacter(String character) {
        this.character = character;
    }
    public String getMailHost() {
        return mailHost;
    }
    public void setMailHost(String mailHost) {
        this.mailHost = mailHost;
    }
    public List<String> getAccessories() {
        return accessories;
    }
    public void setAccessories(List<String> accessories) {
        this.accessories = accessories;
    }
    public String getCheckSend() {
        return isCheckSend;
    }
    public void setCheckSend(String isCheckSend) {
        this.isCheckSend = isCheckSend;
    }
    public List<String> getTos() {
        return tos;
    }
    public void setTos(List<String> tos) {
        this.tos = tos;
    }
    public List<String> getCcs() {
        return ccs;
    }
    public void setCcs(List<String> ccs) {
        this.ccs = ccs;
    }
    public String getIsCheckSend() {
        return isCheckSend;
    }
    public void setIsCheckSend(String isCheckSend) {
        this.isCheckSend = isCheckSend;
    }
    // ��������ռ���
    private  Address[] getAllTake() throws ArrayIndexOutOfBoundsException, AddressException{
        return valueOfAddress(tos);
    }
    private Address[] valueOfAddress(List<String> list) throws ArrayIndexOutOfBoundsException, AddressException{
        Address[] takes = new Address[0];
        if(null == list || list.size() == 0)
            throw new ArrayIndexOutOfBoundsException("list is null");
        takes = new Address[list.size()];
        for(int i = 0; i < list.size();  ++ i) {
            takes[i]  = InternetAddress.parse(list.get(i))[0];
        }
        return takes;
    }
    private Address[] getAllOtherTake() throws ArrayIndexOutOfBoundsException, AddressException {
        if (null == ccs || ccs.size() == 0)
            return new Address[0];   
        else            
            return valueOfAddress(getCcs());
    }
    // �������и���
    private void addBodyPartByMimeMultipart(MimeMultipart mm,
            List<String> filePaths) throws MessagingException,
            ArrayIndexOutOfBoundsException, NullPointerException {
       
        if (null == filePaths || filePaths.size() == 0)
            return;
        if(null == mm)
            throw new NullPointerException("MimeMultipart is null");
        for (int i = 0; i < filePaths.size(); i++) {
            MimeBodyPart bp = new MimeBodyPart();
            FileDataSource fileds = new FileDataSource(filePaths.get(i));
            DataHandler dh = new DataHandler(fileds);
            bp.setDisposition(Part.ATTACHMENT);
            bp.setFileName(fileds.getName());
            bp.setDataHandler(dh);
            mm.addBodyPart(bp);
        }
    }
   
    public boolean send() throws Exception {
        boolean isSend = false;
       
        // ����SMTP���ͷ�����
        Properties props = System.getProperties();
       
        // ����SMTP������
        props.put("mail.smtp.host", mailHost);         
       
        // ��Ҫ������֤
        props.put("mail.smtp.auth", isCheckSend);      
        //Authenticator auth = Authenticator
       
        // ����ʼ��Ự����
        Session session = Session.getDefaultInstance(props,null);
        URLName url = new URLName(this.sendMail);
        PasswordAuthentication pw = new PasswordAuthentication(this.sendMail, this.sendMailPassword);
        session.setPasswordAuthentication(url, pw);
       
        // �ʼ�����
        MimeMessage mimeMsg = new MimeMessage(session);
       
        MimeMultipart multipart = new MimeMultipart();
       
        // �����ʼ���ַ
        mimeMsg.setFrom(new InternetAddress(sendMail));
       
        // �ռ���
        mimeMsg.setRecipients(Message.RecipientType.TO, getAllTake());
       
        mimeMsg.setSentDate(new Date());
        // ������
        mimeMsg.setRecipients(Message.RecipientType.CC, getAllOtherTake());
       
        // ���� ���ַ�����
        mimeMsg.setSubject(getSubject(), getCharacter());
       
        // �����ʼ����ʽ
        BodyPart bp = new MimeBodyPart();
        //bp.setContent("<meta http-equiv=Content-Type content=text/html; charset="+getCharacter()+">"
        //                + content, "text/html;charset="+getCharacter());
       
        bp.setText(content);
       
        ((Logger) log).info(bp.getContent().toString());
        multipart.addBodyPart(bp);
       
       
        // ���Ӹ���
        addBodyPartByMimeMultipart(multipart, getAccessories());
       
        isSend = process(session, mimeMsg, multipart, props);
       
        return isSend;
    }
   
    private boolean process(Session session, MimeMessage mimeMsg, MimeMultipart multipart, Properties props) throws MessagingException {
        boolean isSuccessfully = false;
        mimeMsg.setContent(multipart);
        mimeMsg.saveChanges();
        Session mailSession = Session.getInstance(props, null);
        Transport transport = mailSession.getTransport("smtp");
        transport.connect((String) props.get("mail.smtp.host"), getSendMail(),
                getSendMailPassword());
        transport.sendMessage(mimeMsg, mimeMsg.getAllRecipients());
        ((Logger) log).info("Mail Successfully Sended!");
        transport.close();
        isSuccessfully = true;
        return isSuccessfully;
    }

}

package iss.java.mail;
import java.io.IOException;
//import java.math.BigDecimal;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
//import java.util.Date;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.mail.MessagingException;

import com.google.common.base.Strings;

public class IMailServiceImply2014302580331 implements IMailService {
    /* pool config */
    private static final int COREPOOLSIZE = 10;
    private static final int MAXIMUMPOOLSIZE = 20; //���������
   
    private static ThreadPoolExecutor pool;
    private static BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();
   
    static {
        /**
         *  ʹ��JDK�е��̳߳أ��߳�ִ�в����ޱ߽����
         */
        pool = new ThreadPoolExecutor(COREPOOLSIZE, MAXIMUMPOOLSIZE, 2, TimeUnit.MINUTES, queue);
    }
    public void sendMail(String sendMailAddr, String sendMailPwd,
            List<String> ccs, List<String> tos, String subject,
            String content, List<String> accessories, String mailType, String operMan, String memo) {
       MailThread mail = new MailThread();
       mail.init(sendMailAddr, sendMailPwd, ccs, tos, subject, content, accessories, mailType, operMan, memo);
       pool.execute(mail);
    }
    /**
     *
     * @Program Name : MailServiceImply.java
     *
     */
    class MailThread implements Runnable {
        private final String CHARACTERCONFIG = null;

		private final String CHECKSEND = null;

		private List<String> ccs;
        private List<String> tos;
        private List<String> accessories;
       
        private String sendMailAddr;
        private String sendMailPwd;
        private String subject;
        private String content;
        private String mailType;
        private String operMan;
        private String memo;
       
        /**
         *  ��ʼ���߳�����
         * @param sendMailAddr
         * @param sendMailPwd
         * @param ccs ���ͺ���
         * @param tos �ռ���
         * @param subject ����
         * @param content ����
         * @param accessories ����
         *
         */
        public void init(String sendMailAddr, String sendMailPwd,
                List<String> ccs, List<String> tos, String subject,
                String content, List<String> accessories, String mailType, String operMan, String memo){
            this.sendMailAddr = sendMailAddr;
            this.sendMailPwd = sendMailPwd;
            this.ccs = ccs;
            this.tos = tos;
            this.subject = subject;
            this.content = content;
            this.accessories = accessories;
            this.mailType = mailType;
            this.operMan = operMan;
            this.memo = memo;
        }
        @Override
        public void run() {
           // ((Logger) log).info("�����ʼ���ʼ" + sdf.format(new Date()));
            int id = 0;
            String flag = "0";  //������
            String msg = "";      //������Ϣ
            boolean res = false;// ���ͽ��
            try {
                id = getSeqNo();
                ccs.addAll(queryCCsByMailType(mailType, res)); // ������Ҫ���͵������ַ
             
                // ����������ʼ���־
                saveLog(sendMailAddr, ccs, tos, subject, content, accessories, mailType, operMan, memo, id);
               
                // У������, ȥ�����������ַ
                if(!validate(sendMailAddr, sendMailPwd, ccs, tos, subject, content, accessories)) {
                  System.out.println("����");
                    return;
                }
                // ��ȡ�ʼ�����
                MailControl mail = getMailInstance(sendMailAddr, sendMailPwd, ccs, tos, subject, content, accessories);
               
                // �����ʼ�
                res = mail.send();
                flag = res ? "1" : "2";
                if(!res) msg = "δ֪����,����ʧ��";
               
                // ���·��ͼ�¼
                modifyLog(msg, flag, id);
               
            } catch (Exception e) {
                e.printStackTrace();
                
                modifyLog(e.getMessage(), "2", id);
            }
        }
       
        /**
         * ��ȡ�ʼ�����ʵ��
         * @param sendMailAddr ������
         * @param sendMailPwd ����������
         * @param ccs ����
         * @param tos �ռ���
         * @param subject ����
         * @param content ����
         * @return
         *
         */
        private MailControl getMailInstance(String sendMailAddr, String sendMailPwd,
                List<String> ccs, List<String> tos, String subject,
                String content, List<String> accessories){
            // ��ȡSMTP��ַ
            String mailHost = Operation.getMail2SMTP(sendMailAddr);
           
            // �����ʼ�
            MailControl mail = new MailControl(subject,
                    sendMailAddr,
                    sendMailPwd,
                    tos,  // �ռ���
                    content,
                    Operation.getConfigValue(CHARACTERCONFIG),
                    mailHost,
                    accessories,    // ����
                    Operation.getConfigValue(CHECKSEND),
                    ccs  //����
            );
           
            return mail;
        }
       
        private boolean validate(String sendMailAddr, String sendMailPwd,
                List<String> transmitMails, List<String> takeMail, String subject,
                String content, List<String> multiparts){
            boolean res = true;
            if(!Operation.isEmail(sendMailAddr)) res = false;
            // ����������
            cancelErrorMailAddr(transmitMails);
            cancelErrorMailAddr(takeMail);
           
            return res;
        }
       
        private void cancelErrorMailAddr(List<String> list) {
            if(null == list || list.isEmpty()) return;
            List<String> back = new ArrayList<String>(list);
            for (String email : back) {
                if(!Operation.isEmail(email)) {
                    list.remove(email);
                   // log.info("�Ƴ������ʼ�:" + email);
                }
            }
        }

        private int getSeqNo() {
        	int index = 0;
 			int codePointOffset = 0;
            String seqSql = "select seq_mail.nextval from dual";
          
			// BigDecimal b =  (BigDecimal) new DbUtilsTemplate().findBy(seqSql, 1);
            return seqSql.offsetByCodePoints(index, codePointOffset);
        }
       
        private boolean saveLog(String sendMail, List<String> ccs, List<String> tos, String subject,
                String content, List<String> accessories, String mailType, String operman, String memo, int id) {
           
            StringBuffer sql = new StringBuffer();
            sql.append(" INSERT INTO mail_send_detail ");
            sql.append(" (ID, sendmail, senddate, tos, ccs, subject, CONTEXT, status, ");
            sql.append(" mailtype, accessories, operman, operdate,opermemo) values(?, ?, sysdate, ?, ?, ?, ?, '0', ?, ?, ?, sysdate, ?)");
           
            return true;
           
           // return (1 == new DbUtilsTemplate().update(sql.toString(), params));
        }
       
        private boolean modifyLog(String memo, String flag, int id){
			return false;
        }
        // ��ѯ�ʼ������£� ��Ҫ���͵�
        private List<String> queryCCsByMailType(String mailType, Object emails) {
            List<String> list = new ArrayList<String>();
            // String emails =  (String) new DbUtilsTemplate().findBy(sql, 1, mailType);
            if(Strings.isNullOrEmpty((String) emails)) {
                 list = Arrays.asList(((String) emails).split(";"));
            }
            return list;
        }
    }
	@Override
	public void connect() throws MessagingException {
	}
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO Auto-generated method stub
		return null;
	}
}
